/// ROB4-POO Projet Don't Starve
/// Fichier : Pierre.hpp
///	Autheurs : Benjamin Delbos et Tiphaine Diot
/// Classe Pierre

#ifndef PIER_HPP
#define PIER_HPP

#include <iostream>
#include "Ressource.hpp"

class Pierre : public Ressource{

public: 
	Pierre(){}
	
};

#endif
