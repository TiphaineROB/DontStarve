/// ROB4-POO Projet Don't Starve
/// Fichier : Bois.hpp
///	Autheurs : Benjamin Delbos et Tiphaine Diot
/// Classe Bois

#ifndef BOIS_HPP
#define BOIS_HPP

#include <iostream>
#include "Ressource.hpp"

class Bois : public Ressource{

public: 

	Bois(){}
	
	std::string getType(){
		return "Bois";
	} 
	
};

#endif
