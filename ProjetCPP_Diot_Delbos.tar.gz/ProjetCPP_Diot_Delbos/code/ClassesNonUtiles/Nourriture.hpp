/// ROB4-POO Projet Don't Starve
/// Fichier : Nourriture.hpp
///	Autheurs : Benjamin Delbos et Tiphaine Diot
/// Classe Nourriture

#ifndef NOUR_HPP
#define NOUR_HPP

#include <iostream>

class Nourriture{

public: 
	void utiliser();


protected:
	double _peremption;
	int apportNour;
	//sf::Texture _img;
};

#endif